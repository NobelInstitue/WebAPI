﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using UserServiceAPI.Models;

namespace UserServiceAPI.Controllers
{
    [EnableCors("AllowAllOrigin")] // Apply specific CORS policy to this controller
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserRepository _userRepository;

        public UserController(UserRepository userRepository)
        {
            _userRepository = userRepository;
        }
        [EnableCors("AllowSpecificOrigin")]
        [HttpGet]
        public async Task<ActionResult<List<User>>> GetAllUsers()
        {
            return Ok(await _userRepository.GetAllUsersAsync());
        }
        [EnableCors("AllowSpecificOrigin")]
        [HttpGet("{id}")]
        public async Task<ActionResult<User>> GetUserById(int id)
        {
            var user = await _userRepository.GetUserByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }
        [EnableCors("AllowSpecificOrigin")]
        [HttpPost]
        public async Task<ActionResult> AddUser(User user)
        {
            await _userRepository.AddUserAsync(user);
            return CreatedAtAction(nameof(GetUserById), new { id = user.Id }, user);
        }
        [EnableCors("AllowAnotherSpecificOrigin")]
        [DisableCors]
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateUser(int id, User user)
        {
            if (id != user.Id)
            {
                return BadRequest();
            }
            await _userRepository.UpdateUserAsync(user);
            return NoContent();
        }
        [EnableCors("AllowAnotherSpecificOrigin")]
        [DisableCors]
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteUser(int id)
        {
            await _userRepository.DeleteUserAsync(id);
            return NoContent();
        }
    }
}