using Microsoft.EntityFrameworkCore;
using UserServiceAPI.Models;

namespace UserServiceAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers()
               .AddJsonOptions(options =>
               {
                   // This will use the property names as defined in the C# model
                   options.JsonSerializerOptions.PropertyNamingPolicy = null;
               });

            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            //Configure the ConnectionString and DbContext class
            builder.Services.AddDbContext<UserDbContext>(options =>
            {
                options.UseSqlServer(builder.Configuration.GetConnectionString("EFCoreDBConnection"));
            });

            // Register UserRepository
            builder.Services.AddScoped<UserRepository>();

            // Configure CORS policy to allow requests from the client application
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAllOrigin",
                    builder =>
                    {
                        builder.AllowAnyOrigin()  // Allow any Origins
                               .AllowAnyHeader()  // Allow any headers (like Content-Type)
                               .AllowAnyMethod(); // Allow any HTTP methods (GET, POST, etc.)
                    });
            });

            //// Configure CORS policy to allow specific origins, headers, and methods
            //builder.Services.AddCors(options =>
            //{
            //    options.AddPolicy("AllowSpecificOrigin", policy =>
            //    {
            //        policy.WithOrigins("https://localhost:7196", "https://example.com") // Add client origin
            //              .WithHeaders("Content-Type", "Authorization", "Any-Custom-Header", "Accept") // Allow specific headers
            //              .WithMethods("GET", "POST", "PUT", "DELETE"); // Allow specific methods
            //    });
            //});


            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();
            //Apply CORS Globally
            app.UseCors("AllowAllOrigin");
            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}