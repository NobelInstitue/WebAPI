﻿using HTTPMethodsWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HTTPMethodsWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ProductDbContext _context;
        public ProductsController(ProductDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            try
            {
                var products = await _context.Products.ToListAsync();
                return Ok(products); // Returns 200 OK with the list of products
            }
            catch (Exception ex)
            {
                // Handles any unexpected errors
                return StatusCode(500, new { Message = "An error occurred while retrieving products.", Details = ex.Message });
            }
        }
        // HTTP GET Method: Retrieve product by ID (Safe, Idempotent)
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProductById(int id)
        {
            try
            {
                var product = await _context.Products.FindAsync(id);
                if (product == null)
                    return NotFound(new { Message = $"Product with ID {id} not found." }); // Returns 404 Not Found if product does not exist
                return Ok(product); // Returns 200 OK with the product
            }
            catch (Exception ex)
            {
                // Handles any unexpected errors
                return StatusCode(500, new { Message = "An error occurred while retrieving the product.", Details = ex.Message });
            }
        }
        // HTTP POST Method: Create a new product (Unsafe, Non-Idempotent)
        // Creates new resources, which makes it unsafe and non-idempotent.
        [HttpPost]
        public async Task<IActionResult> CreateProduct([FromBody] Product product)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState); // Returns 400 Bad Request if validation fails
                await _context.Products.AddAsync(product);
                await _context.SaveChangesAsync();
                // Return a created response with the URI of the new product
                return CreatedAtAction(nameof(GetProductById), new { id = product.Id }, product); // Returns 201 Created
            }
            catch (Exception ex)
            {
                // Handles any unexpected errors
                return StatusCode(500, new { Message = "An error occurred while creating the product.", Details = ex.Message });
            }
        }
        // HTTP PUT Method: Update existing product by replacing it entirely (Unsafe, Idempotent)
        // Updates the entire resource, making it unsafe but idempotent.
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] Product product)
        {
            try
            {
                if (id != product.Id)
                    return BadRequest("Product ID mismatch."); // Returns 400 Bad Request if IDs do not match
                var existingProduct = await _context.Products.FindAsync(id);
                if (existingProduct == null)
                    return NotFound(new { Message = $"Product with ID {id} not found." }); // Returns 404 Not Found if product does not exist
                // Update product properties
                existingProduct.Name = product.Name;
                existingProduct.Price = product.Price;
                existingProduct.Description = product.Description;
                await _context.SaveChangesAsync(); // Saves changes to the database
                return NoContent(); // Returns 204 No Content on success
            }
            catch (DbUpdateException ex)
            {
                //Handle database exception
                return StatusCode(500, new { Message = "An error occurred while updating the product.", Details = ex.InnerException?.Message ?? ex.Message });
            }
            catch (Exception ex)
            {
                // Handles any unexpected errors
                return StatusCode(500, new { Message = "An error occurred while updating the product.", Details = ex.Message });
            }
        }
        // HTTP PATCH Method: Partial update of an existing product (Unsafe, Idempotent)
        // Partially updates a resource, unsafe and potentially idempotent depending on how it’s used.
        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateProductPrice(int id, [FromBody] Product product)
        {
            try
            {
                if (id != product.Id)
                    return BadRequest("Product ID mismatch."); // Returns 400 Bad Request if IDs do not match
                var existingProduct = await _context.Products.FindAsync(id);
                if (existingProduct == null)
                    return NotFound(new { Message = $"Product with ID {id} not found." }); // Returns 404 Not Found if product does not exist
                // Only update the price
                existingProduct.Price = product.Price;
                await _context.SaveChangesAsync(); // Saves changes to the database
                return NoContent(); // Returns 204 No Content on success
            }
            catch (DbUpdateException ex)
            {
                //Handle database exception
                return StatusCode(500, new { Message = "An error occurred while updating the product.", Details = ex.InnerException?.Message ?? ex.Message });
            }
            catch (Exception ex)
            {
                // Handles any unexpected errors
                return StatusCode(500, new { Message = "An error occurred while updating the product price.", Details = ex.Message });
            }
        }
        // HTTP DELETE Method: Delete an existing product (Unsafe, Idempotent)
        // Removes a resource, unsafe but idempotent because once deleted, subsequent deletes have no effect.
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            try
            {
                var product = await _context.Products.FindAsync(id);
                if (product == null)
                    return NotFound(new { Message = $"Product with ID {id} not found." }); // Returns 404 Not Found if product does not exist
                _context.Products.Remove(product);
                await _context.SaveChangesAsync(); // Saves changes to the database
                return NoContent(); // Returns 204 No Content on success
            }
            catch (DbUpdateException ex)
            {
                //Handle database exception
                return StatusCode(500, new { Message = "An error occurred while updating the product.", Details = ex.InnerException?.Message ?? ex.Message });
            }
            catch (Exception ex)
            {
                // Handles any unexpected errors
                return StatusCode(500, new { Message = "An error occurred while deleting the product.", Details = ex.Message });
            }
        }
        // HTTP HEAD Method: Retrieve metadata (headers) for a product without fetching the body
        // Retrieves only headers, safe and idempotent.
        [HttpHead("{id}")]
        public async Task<IActionResult> HeadProduct(int id)
        {
            try
            {
                var productExists = await _context.Products.AnyAsync(p => p.Id == id);
                if (!productExists)
                    return NotFound(); // Returns 404 Not Found if product does not exist
                // Add desired headers
                // Set Content-Type header to indicate the media type of the resource (JSON in this case)
                Response.Headers.Append("Content-Type", "application/json");
                // Set Content-Length header to indicate the size of the response body (though body is not returned in HEAD request)
                var contentLength = System.Text.Json.JsonSerializer.Serialize(productExists).Length;
                Response.Headers.Append("Content-Length", contentLength.ToString());
                // Add a custom header (e.g., "X-Custom-Header")
                Response.Headers.Append("X-Custom-Header", "CustomHeaderValue");
                // Return status 200 OK (with headers only)
                return Ok();
            }
            catch (Exception ex)
            {
                // Handles any unexpected errors
                return StatusCode(500, new { Message = "An error occurred while retrieving product metadata.", Details = ex.Message });
            }
        }
        // HTTP OPTIONS Method: List allowed methods for this controller (Safe)
        // Safe and idempotent, useful for preflight requests or discovering allowed methods.
        [HttpOptions]
        public IActionResult GetOptions()
        {
            try
            {
                // Returns the list of supported HTTP methods
                Response.Headers.Append("Allow", "GET, POST, PUT, PATCH, DELETE, OPTIONS, HEAD");
                return Ok(); // Returns 200 OK with Allow header
            }
            catch (Exception ex)
            {
                // Handles any unexpected errors
                return StatusCode(500, new { Message = "An error occurred while retrieving options.", Details = ex.Message });
            }
        }
    }
}
