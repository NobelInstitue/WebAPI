using Microsoft.AspNetCore.Mvc;
using UserClientApp.Models;
using System.Text.Json;

namespace UserClientApp.Controllers
{
    public class HomeController : Controller
    {
        //This action method will load the list of users from the API
        //and pass it to the view on the initial load.
        public async Task<IActionResult> Index()
        {
            //Create an Instance of HttpClient
            HttpClient _httpClient = new HttpClient();

            //Set the base Address
            //Please replace the port on which your Web API Application is running
            _httpClient.BaseAddress = new Uri("https://localhost:7256");

            //When the Page Load we want to display the List of User
            //Specify the endpoint which returns the list of Users
            //Here, we will not get any CORS issue, this is because of Server to Server call
            //That means the MVC Application Server will communicate with the Web API Server
            var response = await _httpClient.GetStringAsync("api/User/GetAllUsers");

            //Convert the Response which is in JSON format to List<User>
            var users = JsonSerializer.Deserialize<List<User>>(response);

            //Pass the List of Users to the View
            return View(users);
        }
    }
}